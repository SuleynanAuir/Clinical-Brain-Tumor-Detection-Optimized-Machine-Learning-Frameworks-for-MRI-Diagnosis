import numpy as np

def extract_data_from_df(df):
    images = list()
    labels = list()
    
    # inter run through each row of dataframe
    for index, row in df.iterrows():
        # the input setting df's colname is 'image'
        img = row['normalized_image_data']
        label = row['label']
        
        # add each row's array data into a list
        # then transform into an array type
        images.append(img)
        labels.append(label)
        
    # output 2 items, one is images array, 
    return np.array(images), np.array(labels)
