# import numpy as np
# import pandas as pd

# def stat_matrix(y_true, y_pred, average=None):
#     y_true = y_true.astype(int)
#     y_pred = y_pred.astype(int)
    
#     classes = np.unique(np.concatenate([y_true, y_pred]))
#     confusion_matrix = np.zeros((len(classes), len(classes)), dtype=int)
    
#     for true, pred in zip(y_true, y_pred):
    
#         confusion_matrix[true, pred] += 1
    
#     precision = np.zeros(len(classes))
#     recall = np.zeros(len(classes))
#     f1 = np.zeros(len(classes))
#     for i in range(len(classes)):
#         precision[i] = confusion_matrix[i, i] / np.sum(confusion_matrix[:, i]) if np.sum(confusion_matrix[:, i]) != 0 else 0
#         recall[i] = confusion_matrix[i, i] / np.sum(confusion_matrix[i, :]) if np.sum(confusion_matrix[i, :]) != 0 else 0
        
#         if precision[i] + recall[i] > 0:
#             f1[i] = 2 * (precision[i] * recall[i]) / (precision[i] + recall[i])
#         else:
#             f1[i] = 0
#     if average == 'macro':
#         return np.mean(precision), np.mean(recall), np.mean(f1)
    
#     elif average == 'weighted':
#         weights = np.sum(confusion_matrix, axis=1)  
#         weighted_precision = np.sum(precision * weights) / np.sum(weights)
#         weighted_recall = np.sum(recall * weights) / np.sum(weights)
#         weighted_f1 = np.sum(f1 * weights) / np.sum(weights)
#         return weighted_precision, weighted_recall, weighted_f1
    
#     elif average == 'micro':
#         total_true_positive = np.sum(np.diagonal(confusion_matrix))
#         total_false_positive = np.sum(np.sum(confusion_matrix, axis=0) - np.diagonal(confusion_matrix))
#         total_false_negative = np.sum(np.sum(confusion_matrix, axis=1) - np.diagonal(confusion_matrix))
#         total_precision = total_true_positive / (total_true_positive + total_false_positive)
#         total_recall = total_true_positive / (total_true_positive + total_false_negative)
#         total_f1 = 2 * (total_precision * total_recall) / (total_precision + total_recall)
#         return total_precision, total_recall, total_f1
    
#     else:
#         return precision, recall, f1

# def classification_pred_report(y_true, y_pred, target_names=None, digits=4, average=None):
#     precision, recall, f1 = stat_matrix(y_true, y_pred, average)
    
#     if target_names is None:
#         target_names = [str(i) for i in np.unique(np.concatenate([y_true, y_pred]))]
#     report_df = pd.DataFrame(index=target_names, columns=["precision", "recall", "f1-score", "support"])
    
#     for i, label in enumerate(target_names):
#         report_df.loc[label, "precision"] = round(precision[i], digits)
#         report_df.loc[label, "recall"] = round(recall[i], digits)
#         report_df.loc[label, "f1-score"] = round(f1[i], digits)
#         report_df.loc[label, "support"] = np.sum(np.array(y_true) == int(label))  
#     if average is not None:
#         avg_precision, avg_recall, avg_f1 = stat_matrix(y_true, y_pred, average)
#         report_df.loc['average'] = {
#             'precision': round(avg_precision, digits),
#             'recall': round(avg_recall, digits),
#             'f1-score': round(avg_f1, digits),
#             'support': ''
#         }
#     # print(report_df)
    
#     return report_df

import numpy as np
import pandas as pd

def stat_matrix(y_true, y_pred, average=None):
    y_true = np.nan_to_num(y_true)  # NaN -> 0
    y_pred = np.nan_to_num(y_pred)  # NaN -> 0
    
    # round number
    y_true = np.round(y_true).astype(int)
    y_pred = np.round(y_pred).astype(int)

    # extract all the labels in data
    classes = np.unique(np.concatenate([y_true, y_pred]))
    
    # init the matrix
    confusion_matrix = np.zeros((len(classes), len(classes)), dtype=int)
    
    # fill the matrix value blank
    for true, pred in zip(y_true, y_pred):
        confusion_matrix[true, pred] += 1
    
    precision = np.zeros(len(classes))
    recall = np.zeros(len(classes))
    f1 = np.zeros(len(classes))
    
    for i in range(len(classes)):
        precision[i] = confusion_matrix[i, i] / np.sum(confusion_matrix[:, i]) if np.sum(confusion_matrix[:, i]) != 0 else 0
        recall[i] = confusion_matrix[i, i] / np.sum(confusion_matrix[i, :]) if np.sum(confusion_matrix[i, :]) != 0 else 0
        
        if precision[i] + recall[i] > 0:
            f1[i] = 2 * (precision[i] * recall[i]) / (precision[i] + recall[i])
        else:
            f1[i] = 0
    
    # based on the chosen mode to output
    if average == 'macro':
        return np.mean(precision), np.mean(recall), np.mean(f1)
    
    elif average == 'weighted':
        weights = np.sum(confusion_matrix, axis=1)  
        weighted_precision = np.sum(precision * weights) / np.sum(weights)
        weighted_recall = np.sum(recall * weights) / np.sum(weights)
        weighted_f1 = np.sum(f1 * weights) / np.sum(weights)
        return weighted_precision, weighted_recall, weighted_f1
    
    elif average == 'micro':
        total_true_positive = np.sum(np.diagonal(confusion_matrix))
        total_false_positive = np.sum(np.sum(confusion_matrix, axis=0) - np.diagonal(confusion_matrix))
        total_false_negative = np.sum(np.sum(confusion_matrix, axis=1) - np.diagonal(confusion_matrix))
        total_precision = total_true_positive / (total_true_positive + total_false_positive)
        total_recall = total_true_positive / (total_true_positive + total_false_negative)
        total_f1 = 2 * (total_precision * total_recall) / (total_precision + total_recall)
        return total_precision, total_recall, total_f1
    
    else:
        return precision, recall, f1

def classification_pred_report(y_true, y_pred, target_names=None, digits=4, average=None):
    
    precision, recall, f1 = stat_matrix(y_true, y_pred, average)
    
    if target_names is None:
        target_names = [str(i) for i in np.unique(np.concatenate([y_true, y_pred]))]
    
    report_df = pd.DataFrame(index=target_names, columns=["precision", "recall", "f1-score", "support"])
    
    for i, label in enumerate(target_names):
        try:
            int_label = int(float(label))  
        except ValueError:
            print(f"Warning: Invalid label {label}. Skipping this label.")
            continue
        
        report_df.loc[label, "precision"] = round(precision[i], digits)
        report_df.loc[label, "recall"] = round(recall[i], digits)
        report_df.loc[label, "f1-score"] = round(f1[i], digits)
        report_df.loc[label, "support"] = np.sum(np.array(y_true) == int_label)  # count the support

    # compute the avg
    if average is not None:
        avg_precision, avg_recall, avg_f1 = stat_matrix(y_true, y_pred, average)
        report_df.loc['average'] = {
            'precision': round(avg_precision, digits),
            'recall': round(avg_recall, digits),
            'f1-score': round(avg_f1, digits),
            'support': ''
        }
    
    # output report
    # print(report_df)
    
    return report_df
