import numpy as np
import matplotlib.pyplot as plt
from skimage.draw import line

# compute HOG Feature Values
def compute_hog(gray_image, pixels_per_cell=(8, 8), cells_per_block=(2, 2), nbins=9):

    gx = np.zeros_like(gray_image)
    gy = np.zeros_like(gray_image)
    gx[:, 1:-1] = gray_image[:, 2:] - gray_image[:, :-2]
    gy[1:-1, :] = gray_image[2:, :] - gray_image[:-2, :]

    # compute magnitude / orientation value
    magnitude = np.sqrt(gx ** 2 + gy ** 2)
    orientation = np.rad2deg(np.arctan2(gy, gx)) % 180

    # replace Nan
    orientation = np.nan_to_num(orientation)

    # split the image into cells
    cell_rows, cell_cols = pixels_per_cell
    n_cells_y = gray_image.shape[0] // cell_rows
    n_cells_x = gray_image.shape[1] // cell_cols

    orientation_histogram = np.zeros((n_cells_y, n_cells_x, nbins))
    bin_width = 180 // nbins

    # make histogram for each cell
    for i in range(n_cells_y):
        for j in range(n_cells_x):
            mag_cell = magnitude[i*cell_rows:(i+1)*cell_rows, j*cell_cols:(j+1)*cell_cols].ravel()
            ori_cell = orientation[i*cell_rows:(i+1)*cell_rows, j*cell_cols:(j+1)*cell_cols].ravel()

            hist = np.zeros(nbins)
            for mag, angle in zip(mag_cell, ori_cell):
                # promise angle not NaN
                if np.isnan(angle):
                    continue  # Nan drop...
                
                # bin index
                bin_idx = int(angle // bin_width) % nbins
                hist[bin_idx] += mag
            orientation_histogram[i, j, :] = hist

    # Block normalization
    block_rows, block_cols = cells_per_block
    n_blocks_y = n_cells_y - block_rows + 1
    n_blocks_x = n_cells_x - block_cols + 1
    features = []

    for i in range(n_blocks_y):
        for j in range(n_blocks_x):
            block = orientation_histogram[i:i+block_rows, j:j+block_cols, :].ravel()
            norm = np.linalg.norm(block) + 1e-5
            features.append(block / norm)
    
    features = np.concatenate(features)

    # visualization on HOG Features
    hog_image = np.zeros_like(gray_image, dtype=float)
    center_y = cell_rows // 2
    center_x = cell_cols // 2

    # visualization on HOG Features
    for i in range(n_cells_y):
        for j in range(n_cells_x):
            cell_hist = orientation_histogram[i, j]
            cell_mag = cell_hist / (np.linalg.norm(cell_hist) + 1e-5)  # normalize for visualization

            for b in range(nbins):
                angle = b * bin_width + bin_width / 2
                angle_rad = np.deg2rad(angle)
                x1 = int(j * cell_cols + center_x - np.cos(angle_rad) * cell_cols // 2)
                y1 = int(i * cell_rows + center_y - np.sin(angle_rad) * cell_rows // 2)
                x2 = int(j * cell_cols + center_x + np.cos(angle_rad) * cell_cols // 2)
                y2 = int(i * cell_rows + center_y + np.sin(angle_rad) * cell_rows // 2)
                rr, cc = draw_line(y1, x1, y2, x2, gray_image.shape)
                hog_image[rr, cc] += cell_mag[b]

    hog_image = (hog_image - hog_image.min()) / (hog_image.max() - hog_image.min() + 1e-5)
    return features, hog_image

# draw the lines on HOG feature maps
def draw_line(y0, x0, y1, x1, shape):
    rr, cc = line(y0, x0, y1, x1)
    valid = (rr >= 0) & (rr < shape[0]) & (cc >= 0) & (cc < shape[1])
    return rr[valid], cc[valid]

# rgb image transform into the gray image
def rgb2gray(image):
    return np.dot(image[...,:3], [0.2989, 0.587, 0.114])
