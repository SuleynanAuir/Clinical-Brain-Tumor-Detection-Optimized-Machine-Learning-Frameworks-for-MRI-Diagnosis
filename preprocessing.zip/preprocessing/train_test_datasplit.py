import numpy as np
import pandas as pd

def train_test_datasplit(*arrays, 
                     test_size = 0.2,
                     random_state = None
                     ):
    """
    *array: datatype similar with Array / List
    test_size: default as 20%
    random_state: None init
    """
    
    # setting random number
    if random_state is not None:
        np.random.seed(random_state)
    
    # make array into flopped array
    arrays = [np.asarray(arr) for arr in arrays]
    
    sample_num = arrays[0].shape[0]
    
    # test sample number
    test_num = int(sample_num * test_size)
    
    # shuffle for data
    # output <<< index list
    indices = np.random.permutation(sample_num)
    
    # record certain position idx number
    train_idx = indices[test_num : ]
    test_idx = indices[ : test_num]
    
    result = list()
    
    for array in arrays:
        result.append(array[train_idx])
        result.append(array[test_idx])
        
    return tuple(result)