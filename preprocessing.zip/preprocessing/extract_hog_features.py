# import numpy as np
# from compute_hog import compute_hog

# # a = 1

# def extract_hog_features(images):
#     """
#     images: >>> array(list of arrays)
#     """
#     hog_features = list()
    
#     # run through each image's array one by one
#     for idx, image in enumerate(images):
#         # channel = 3
#         if len(image.shape) == 3:
#             # transform into gray image
#             # (H * W * 3) @ (3 * 1) => gray img
#             gray_image = np.dot(
#                 image[..., :3], 
#                 [0.2989, 0.587, 0.114]
#             )
        
#         # channel = 1
#         else:
#             gray_image = image
            
#         features, _ = compute_hog(
#             gray_image,
#             pixels_per_cell = (8, 8),
#             cells_per_block = (2, 2),
#             nbins = 9
#         )
        
#         hog_features.append(features)
#         # print(f'No.{a} Finished!', end=' ')
#         if (idx + 1) % 100 == 0 or (idx + 1) == len(images):
#             print(f"Processed {idx + 1}/{len(images)} images")

        
#         # a += 1
    
#     return np.array(hog_features)

import numpy as np
from compute_hog import compute_hog
from tqdm import tqdm  # Import tqdm for progress bar

def extract_hog_features(images):
    """
    images: >>> array(list of arrays)
    """
    hog_features = list()
    
    # Initialize tqdm with the total length of images for progress bar
    for idx, image in tqdm(enumerate(images), total=len(images), desc="Processing Images", unit="image"):
        # channel = 3
        if len(image.shape) == 3:
            # transform into gray image
            # (H * W * 3) @ (3 * 1) => gray img
            gray_image = np.dot(
                image[..., :3], 
                [0.2989, 0.587, 0.114]
            )
        
        # channel = 1
        else:
            gray_image = image
            
        features, _ = compute_hog(
            gray_image,
            pixels_per_cell=(8, 8),
            cells_per_block=(2, 2),
            nbins=9
        )
        
        hog_features.append(features)
        
    return np.array(hog_features)
